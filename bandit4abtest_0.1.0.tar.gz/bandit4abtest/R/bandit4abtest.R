#' bandit4abtest Package
#'
#' Contains functions for imrpove traditionnal A/B test by methodes from bandit theory.
#'
#' @docType package
#'
#' @author Emmanuelle Claeys \email{claeys@unistra.fr}
#'
#' @name bandit4abtest
NULL
